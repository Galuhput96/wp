<?php
/*
Plugin Name: Post Date Spin Pro
Description: Spin tanggal post secara manual dan otomatis harian dengan setting lengkap, log dan kategori.
Version: 1.0
Author: ChatGPT
*/

if (!defined('ABSPATH')) exit;

class PostDateSpinPro {
    private $option_group = 'pds_options_group';
    private $option_name = 'pds_options';
    private $options;

    public function __construct() {
        $this->options = get_option($this->option_name, []);

        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'settings_init']);
        add_action('admin_post_pds_spin_now', [$this, 'handle_manual_spin']);
        add_action('admin_post_pds_clear_log', [$this, 'handle_clear_log']);

        // Cron schedule
        register_activation_hook(__FILE__, [$this, 'activate_cron']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate_cron']);
        add_action('pds_daily_spin_event', [$this, 'do_daily_spin']);
    }

    public function add_admin_menu() {
        add_menu_page('Post Date Spin', 'Post Date Spin', 'manage_options', 'post-date-spin', [$this, 'admin_page'], 'dashicons-clock', 90);
    }

    public function settings_init() {
        register_setting($this->option_group, $this->option_name, [$this, 'validate_settings']);

        add_settings_section('pds_section_main', 'Pengaturan Spin Tanggal Post', null, $this->option_group);

        add_settings_field('spin_source_year_from', 'Tahun Sumber Dari', [$this, 'field_spin_source_year_from'], $this->option_group, 'pds_section_main');
        add_settings_field('spin_source_year_to', 'Tahun Sumber Sampai', [$this, 'field_spin_source_year_to'], $this->option_group, 'pds_section_main');

        add_settings_field('spin_result_year_from', 'Tahun Hasil Dari', [$this, 'field_spin_result_year_from'], $this->option_group, 'pds_section_main');
        add_settings_field('spin_result_year_to', 'Tahun Hasil Sampai', [$this, 'field_spin_result_year_to'], $this->option_group, 'pds_section_main');

        add_settings_field('spin_category', 'Kategori (slug, pisah koma)', [$this, 'field_spin_category'], $this->option_group, 'pds_section_main');

        add_settings_field('daily_spin_count', 'Jumlah Post Spin Harian', [$this, 'field_daily_spin_count'], $this->option_group, 'pds_section_main');
    }

    // Field callbacks
    public function field_spin_source_year_from() {
        $val = $this->options['spin_source_year_from'] ?? 2014;
        echo '<input type="number" name="pds_options[spin_source_year_from]" value="' . esc_attr($val) . '" min="2000" max="2100">';
        echo '<p class="description">Rentang tahun awal sumber tanggal post.</p>';
    }
    public function field_spin_source_year_to() {
        $val = $this->options['spin_source_year_to'] ?? date('Y');
        echo '<input type="number" name="pds_options[spin_source_year_to]" value="' . esc_attr($val) . '" min="2000" max="2100">';
        echo '<p class="description">Rentang tahun akhir sumber tanggal post.</p>';
    }
    public function field_spin_result_year_from() {
        $val = $this->options['spin_result_year_from'] ?? date('Y');
        echo '<input type="number" name="pds_options[spin_result_year_from]" value="' . esc_attr($val) . '" min="2000" max="2100">';
        echo '<p class="description">Rentang tahun awal hasil tanggal spin.</p>';
    }
    public function field_spin_result_year_to() {
        $val = $this->options['spin_result_year_to'] ?? date('Y');
        echo '<input type="number" name="pds_options[spin_result_year_to]" value="' . esc_attr($val) . '" min="2000" max="2100">';
        echo '<p class="description">Rentang tahun akhir hasil tanggal spin.</p>';
    }
    public function field_spin_category() {
        $val = $this->options['spin_category'] ?? '';
        echo '<input type="text" name="pds_options[spin_category]" value="' . esc_attr($val) . '" placeholder="misal: berita,review">';
        echo '<p class="description">Masukkan slug kategori, pisahkan dengan koma. Kosong = semua kategori.</p>';
    }
    public function field_daily_spin_count() {
        $val = $this->options['daily_spin_count'] ?? 5;
        echo '<input type="number" min="1" name="pds_options[daily_spin_count]" value="' . esc_attr($val) . '">';
        echo '<p class="description">Jumlah post yang akan di-spin otomatis setiap hari.</p>';
    }

    public function validate_settings($input) {
        $output = [];
        $output['spin_source_year_from'] = intval($input['spin_source_year_from'] ?? 2014);
        if ($output['spin_source_year_from'] < 2000) $output['spin_source_year_from'] = 2014;
        $output['spin_source_year_to'] = intval($input['spin_source_year_to'] ?? date('Y'));
        if ($output['spin_source_year_to'] < $output['spin_source_year_from']) $output['spin_source_year_to'] = $output['spin_source_year_from'];

        $output['spin_result_year_from'] = intval($input['spin_result_year_from'] ?? date('Y'));
        if ($output['spin_result_year_from'] < 2000) $output['spin_result_year_from'] = date('Y');

        $output['spin_result_year_to'] = intval($input['spin_result_year_to'] ?? date('Y'));
        if ($output['spin_result_year_to'] < $output['spin_result_year_from']) $output['spin_result_year_to'] = $output['spin_result_year_from'];

        $output['spin_category'] = sanitize_text_field($input['spin_category'] ?? '');

        $output['daily_spin_count'] = intval($input['daily_spin_count'] ?? 5);
        if ($output['daily_spin_count'] < 1) $output['daily_spin_count'] = 5;

        return $output;
    }

    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Post Date Spin Pro</h1>

            <form method="post" action="options.php">
                <?php
                settings_fields($this->option_group);
                do_settings_sections($this->option_group);
                submit_button('Simpan Pengaturan');
                ?>
            </form>

            <hr>

            <h2>Spin Manual</h2>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                <?php wp_nonce_field('pds_spin_now_nonce'); ?>
                <input type="hidden" name="action" value="pds_spin_now">
                <p>
                    <label><input type="radio" name="spin_mode" value="all" checked> Semua Post</label><br>
                    <label><input type="radio" name="spin_mode" value="hundred"> 100 Post Acak</label><br>
                    <label><input type="radio" name="spin_mode" value="category"> Berdasarkan Kategori (isi di pengaturan)</label><br>
                </p>
                <p><input type="submit" class="button button-primary" value="Spin Sekarang"></p>
            </form>

            <hr>

            <h2>Log Spin</h2>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" onsubmit="return confirm('Yakin ingin menghapus log spin?');">
                <?php wp_nonce_field('pds_clear_log_nonce'); ?>
                <input type="hidden" name="action" value="pds_clear_log">
                <input type="submit" class="button button-secondary" value="Clear Log">
            </form>
            <?php
            $log = get_option('pds_spin_log', []);
            if (!$log) {
                echo '<p>Tidak ada log spin.</p>';
            } else {
                echo '<table class="widefat fixed striped" style="margin-top:1em;"><thead><tr><th>Judul Post</th><th>Tanggal Lama</th><th>Tanggal Baru</th><th>Waktu Spin</th><th>Otomatis?</th></tr></thead><tbody>';
                foreach ($log as $entry) {
                    echo '<tr>';
                    echo '<td>' . esc_html($entry['post_title']) . '</td>';
                    echo '<td>' . esc_html($entry['old_date']) . '</td>';
                    echo '<td>' . esc_html($entry['new_date']) . '</td>';
                    echo '<td>' . esc_html($entry['spin_time']) . '</td>';
                    echo '<td>' . ($entry['auto'] ? 'Ya' : 'Manual') . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table>';
            }
            ?>

        </div>
        <?php
    }

    // Manual spin handler
    public function handle_manual_spin() {
        if (!current_user_can('manage_options')) wp_die('Tidak ada akses');
        check_admin_referer('pds_spin_now_nonce');

        $mode = $_POST['spin_mode'] ?? 'all';
        $opt = get_option($this->option_name);

        $source_from = $opt['spin_source_year_from'] ?? 2014;
        $source_to = $opt['spin_source_year_to'] ?? date('Y');

        $result_from = $opt['spin_result_year_from'] ?? date('Y');
        $result_to = $opt['spin_result_year_to'] ?? date('Y');

        $category = $opt['spin_category'] ?? '';

        $args = [
            'post_type' => 'post',
            'post_status' => 'publish',
            'orderby' => 'rand',
        ];

        // filter by source date
        $args['date_query'] = [
            [
                'after' => "$source_from-01-01 00:00:00",
                'before' => "$source_to-12-31 23:59:59",
                'inclusive' => true,
            ],
        ];

        // filter by category if mode category
        if ($mode === 'category' && !empty($category)) {
            $cats = array_map('trim', explode(',', $category));
            if (count($cats) == 1) {
                $args['category_name'] = $cats[0];
            } else {
                $args['category_name'] = implode(',', $cats);
            }
        }

        if ($mode === 'hundred') {
            $args['posts_per_page'] = 100;
        } else {
            $args['posts_per_page'] = -1;
        }

        $posts = get_posts($args);

        if (empty($posts)) {
            wp_redirect(admin_url('admin.php?page=post-date-spin&msg=tidak_ada_post'));
            exit;
        }

        foreach ($posts as $post) {
            $old_date = $post->post_date;

            $new_year = rand($result_from, $result_to);
            $new_month = rand(1, 12);
            $new_day = rand(1, 28);
            $new_hour = rand(0, 23);
            $new_minute = rand(0, 59);
            $new_second = rand(0, 59);

            $new_date = sprintf('%04d-%02d-%02d %02d:%02d:%02d', $new_year, $new_month, $new_day, $new_hour, $new_minute, $new_second);

            wp_update_post([
                'ID' => $post->ID,
                'post_date' => $new_date,
                'post_date_gmt' => get_gmt_from_date($new_date),
            ]);

            $log = get_option('pds_spin_log', []);
            $log[] = [
                'post_title' => $post->post_title,
                'old_date' => $old_date,
                'new_date' => $new_date,
                'spin_time' => current_time('mysql'),
                'auto' => false,
            ];
            // Simpan maksimal 100 log terakhir
            $log = array_slice($log, -100);
            update_option('pds_spin_log', $log);
        }

        wp_redirect(admin_url('admin.php?page=post-date-spin&msg=spin_sukses'));
        exit;
    }

    // Clear log handler
    public function handle_clear_log() {
        if (!current_user_can('manage_options')) wp_die('Tidak ada akses');
        check_admin_referer('pds_clear_log_nonce');

        update_option('pds_spin_log', []);
        wp_redirect(admin_url('admin.php?page=post-date-spin&msg=log_clear'));
        exit;
    }

    // Cron activate/deactivate
    public function activate_cron() {
        if (!wp_next_scheduled('pds_daily_spin_event')) {
            wp_schedule_event(time(), 'daily', 'pds_daily_spin_event');
        }
    }
    public function deactivate_cron() {
        $timestamp = wp_next_scheduled('pds_daily_spin_event');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'pds_daily_spin_event');
        }
    }

    // Daily spin cron callback
    public function do_daily_spin() {
        $opt = get_option($this->option_name);
        if (!$opt) return;

        $source_from = $opt['spin_source_year_from'] ?? 2014;
        $source_to = $opt['spin_source_year_to'] ?? date('Y');

        $result_from = $opt['spin_result_year_from'] ?? date('Y');
        $result_to = $opt['spin_result_year_to'] ?? date('Y');

        $category = $opt['spin_category'] ?? '';
        $daily_count = $opt['daily_spin_count'] ?? 5;

        $args = [
            'post_type' => 'post',
            'posts_per_page' => intval($daily_count),
            'date_query' => [
                [
                    'after' => "$source_from-01-01 00:00:00",
                    'before' => "$source_to-12-31 23:59:59",
                    'inclusive' => true,
                ],
            ],
            'orderby' => 'rand',
            'post_status' => 'publish',
        ];

        if (!empty($category)) {
            $cats = array_map('trim', explode(',', $category));
            if (count($cats) == 1) {
                $args['category_name'] = $cats[0];
            } else {
                $args['category_name'] = implode(',', $cats);
            }
        }

        $posts = get_posts($args);
        if (empty($posts)) return;

        $log = get_option('pds_spin_log', []);

        foreach ($posts as $post) {
            $old_date = $post->post_date;

            $new_year = rand($result_from, $result_to);
            $new_month = rand(1, 12);
            $new_day = rand(1, 28);
            $new_hour = rand(0, 23);
            $new_minute = rand(0, 59);
            $new_second = rand(0, 59);

            $new_date = sprintf('%04d-%02d-%02d %02d:%02d:%02d', $new_year, $new_month, $new_day, $new_hour, $new_minute, $new_second);

            wp_update_post([
                'ID' => $post->ID,
                'post_date' => $new_date,
                'post_date_gmt' => get_gmt_from_date($new_date),
            ]);

            $log[] = [
                'post_title' => $post->post_title,
                'old_date' => $old_date,
                'new_date' => $new_date,
                'spin_time' => current_time('mysql'),
                'auto' => true,
            ];
        }

        // Simpan maksimal 100 log terakhir
        $log = array_slice($log, -100);
        update_option('pds_spin_log', $log);
    }
}

new PostDateSpinPro();
